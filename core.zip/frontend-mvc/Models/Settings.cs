using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace frontend_mvc.Models
{
    public class WebAPISettings
    {
        public string URL;
    }
}
